import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module.js';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.enableCors();
    await app.listen(process.env.PORT ?? 3000);
}

bootstrap().catch((error) => {
    console.error('Error al iniciar la aplicación', error);
    process.exit(1);
});